#property strict
#property version   "1.00"
#property description "GOLD SCALPING PRO: kirim tick MT4 ke backend. Tidak mengeksekusi order."
input string ApiBaseUrl = "https://GANTI-DENGAN-DOMAIN-BACKEND";
input string ApiKey = "ISI_API_KEY_RAHASIA_DI_SINI";
input int SendEverySeconds = 3;

int OnInit(){
   if(SendEverySeconds < 1) return(INIT_PARAMETERS_INCORRECT);
   EventSetTimer(SendEverySeconds);
   Print("GSP MT4 Bridge aktif. Pastikan URL backend diizinkan pada WebRequest.");
   return(INIT_SUCCEEDED);
}
void OnDeinit(const int reason){ EventKillTimer(); }
void OnTimer(){ SendTick(); }
void SendTick(){
   if(StringFind(ApiBaseUrl, "GANTI-") >= 0 || ApiKey == "ISI_API_KEY_RAHASIA_DI_SINI") return;
   RefreshRates();
   double bid = MarketInfo(Symbol(), MODE_BID);
   double ask = MarketInfo(Symbol(), MODE_ASK);
   if(bid <= 0 || ask <= 0 || ask < bid) return;
   // Format numeric fields explicitly using symbol digits.
   string payload = StringFormat("{\"platform\":\"mt4\",\"symbol\":\"%s\",\"bid\":%s,\"ask\":%s,\"time_utc\":\"%s\"}", Symbol(), DoubleToString(bid, Digits), DoubleToString(ask, Digits), TimeToString(TimeGMT(), TIME_DATE|TIME_SECONDS));
   char data[], result[]; string result_headers;
   StringToCharArray(payload, data, 0, WHOLE_ARRAY, CP_UTF8);
   ArrayResize(data, ArraySize(data)-1);
   string headers = "Content-Type: application/json\r\nX-API-Key: " + ApiKey + "\r\n";
   int code = WebRequest("POST", ApiBaseUrl + "/api/bridge/tick", headers, 5000, data, result, result_headers);
   if(code == -1) Print("GSP MT4 Bridge WebRequest error: ", GetLastError());
}
