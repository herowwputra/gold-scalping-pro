#property strict
#property version   "1.00"
#property description "GOLD SCALPING PRO: kirim tick MT5 ke backend. Tidak mengeksekusi order."
input string ApiBaseUrl = "https://GANTI-DENGAN-DOMAIN-BACKEND";
input string ApiKey = "ISI_API_KEY_RAHASIA_DI_SINI";
input int SendEverySeconds = 3;

int OnInit(){
   if(SendEverySeconds < 1) return(INIT_PARAMETERS_INCORRECT);
   EventSetTimer(SendEverySeconds);
   Print("GSP MT5 Bridge aktif. Pastikan URL backend diizinkan pada WebRequest.");
   return(INIT_SUCCEEDED);
}
void OnDeinit(const int reason){ EventKillTimer(); }
void OnTimer(){ SendTick(); }
void SendTick(){
   if(StringFind(ApiBaseUrl, "GANTI-") >= 0 || ApiKey == "ISI_API_KEY_RAHASIA_DI_SINI") return;
   MqlTick tick;
   if(!SymbolInfoTick(_Symbol, tick) || tick.bid <= 0 || tick.ask <= 0 || tick.ask < tick.bid) return;
   int digits = (int)SymbolInfoInteger(_Symbol, SYMBOL_DIGITS);
   string payload = StringFormat("{\"platform\":\"mt5\",\"symbol\":\"%s\",\"bid\":%s,\"ask\":%s,\"time_utc\":\"%s\"}",
      _Symbol, DoubleToString(tick.bid, digits), DoubleToString(tick.ask, digits), TimeToString(TimeGMT(), TIME_DATE|TIME_SECONDS));
   char data[], result[]; string result_headers;
   StringToCharArray(payload, data, 0, WHOLE_ARRAY, CP_UTF8);
   ArrayResize(data, ArraySize(data)-1);
   string headers = "Content-Type: application/json\r\nX-API-Key: " + ApiKey + "\r\n";
   int code = WebRequest("POST", ApiBaseUrl + "/api/bridge/tick", headers, 5000, data, result, result_headers);
   if(code == -1) Print("GSP MT5 Bridge WebRequest error: ", GetLastError());
}
